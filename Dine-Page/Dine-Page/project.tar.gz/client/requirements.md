## Packages
framer-motion | Scroll animations and transitions
date-fns | Date formatting helper

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  serif: ["var(--font-serif)"],
  sans: ["var(--font-sans)"],
}
